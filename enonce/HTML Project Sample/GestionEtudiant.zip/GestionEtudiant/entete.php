<header>
    <div id="logo">

    </div>
    <div id="text_logo">
        GESTION ETUDIANT
    </div>
</header>
<nav>
    <ul>
        <li>
            <a href="">Accueil</a>

        </li>
        <li class="menu-deroulant">
            <a href="#">Admin</a>
            <ul class="sous-menu">
                <li><a href="#">Etudiant</a></li>
                <li><a href="#">Matiere</a></li>
                <li><a href="#">Evaluation</a></li>
            </ul>
        </li>
        <li>
            <a href="">A-Propos</a>
        </li>
    </ul>
</nav>